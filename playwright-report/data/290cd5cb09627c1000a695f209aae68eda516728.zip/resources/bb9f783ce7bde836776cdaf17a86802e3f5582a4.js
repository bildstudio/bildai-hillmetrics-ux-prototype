(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_d1994950._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_d1994950._.js",
  "chunks": [
    "static/chunks/_77b0c2aa._.css",
    "static/chunks/72263_next_a1162a5a._.js",
    "static/chunks/5e696_framer-motion_dist_es_9bb79b15._.js",
    "static/chunks/ecac4_motion-dom_dist_es_0df96a6d._.js",
    "static/chunks/node_modules__pnpm_c9e88334._.js",
    "static/chunks/_ddaf9434._.js"
  ],
  "source": "dynamic"
});
