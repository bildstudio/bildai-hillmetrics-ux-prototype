(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_tsx_e4f28687._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_tsx_e4f28687._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_c58ba6b9._.js",
    "static/chunks/_66f56f2c._.js"
  ],
  "source": "dynamic"
});
