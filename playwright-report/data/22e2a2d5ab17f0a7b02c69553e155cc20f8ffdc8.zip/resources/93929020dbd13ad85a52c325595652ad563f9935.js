(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/[root of the server]__2ae2ec7f._.js", {

"[turbopack]/browser/dev/hmr-client/hmr-client.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_61dcf9ba._.js",
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_58b8c3ee._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[turbopack]/browser/dev/hmr-client/hmr-client.ts [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/processing-history/processing-history-details-blade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/processing-history/processing-history-details-blade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/fetching-history/fetching-history-details-blade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/fetching-history/fetching-history-details-blade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/normalization-history/NormalizationDetailsBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/normalization-history/NormalizationDetailsBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/refinement-history/RefinementDetailsBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/refinement-history/RefinementDetailsBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/calculation-history/CalculationDetailsBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/calculation-history/CalculationDetailsBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/workflow-execution-log/workflow-item-details-blade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/components_d41e8741._.js",
  "static/chunks/components_workflow-execution-log_b8c5995e._.js",
  "static/chunks/components_workflow-execution-log_workflow-item-details-blade_tsx_58b8c3ee._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/workflow-execution-log/workflow-item-details-blade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/view-flux-blade/ViewFluxBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/view-flux-blade/ViewFluxBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/view-flux-blade/FilePreviewBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/components_3b50a0be._.js",
  "static/chunks/_6c26a703._.js",
  "static/chunks/components_view-flux-blade_FilePreviewBlade_tsx_58b8c3ee._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/view-flux-blade/FilePreviewBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/edit-flux-blade/EditFluxBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/edit-flux-blade/EditFluxBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/app/actions/processing-content-history.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/app_actions_processing-content-history_ts_6c42fb54._.js",
  "static/chunks/app_actions_processing-content-history_ts_58b8c3ee._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/app/actions/processing-content-history.ts [app-client] (ecmascript)");
    });
});
}}),
"[project]/app/actions/fetching-content-history.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/app/actions/fetching-content-history.ts [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/layout/global-advanced-filter.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/components_06aea90c._.js",
  "static/chunks/node_modules__pnpm_678da609._.js",
  "static/chunks/components_layout_global-advanced-filter_tsx_5a7e9181._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/layout/global-advanced-filter.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);