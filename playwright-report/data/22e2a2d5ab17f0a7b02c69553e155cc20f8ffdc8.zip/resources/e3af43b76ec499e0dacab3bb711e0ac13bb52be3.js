(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/app_(app)_dashboard_page_tsx_2f7c1466._.js", {

"[project]/app/(app)/dashboard/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>DashboardPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.2.4_@babel+core@7.28.0_@playwright+test@1.54.1_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.2.4_@babel+core@7.28.0_@playwright+test@1.54.1_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.2.4_@babel+core@7.28.0_@playwright+test@1.54.1_react-dom@19.0.0_react@19.0.0__react@19.0.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$view$2d$flux$2d$blade$2f$SummaryOverview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/view-flux-blade/SummaryOverview.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$blade$2d$stack$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/blade-stack-context.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function DashboardPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { openBlade, closeTopBlade } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$blade$2d$stack$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBladeStack"])();
    const handleNavigate = (page, opts)=>{
        const params = new URLSearchParams();
        if (opts?.status) params.set("status", opts.status);
        if (opts?.durationBucket) params.set("durationBucket", opts.durationBucket);
        if (opts?.errorType) params.set("errorType", opts.errorType);
        if (opts?.date) params.set("date", opts.date);
        if (page === "activity") {
            router.push(`/recent-activity` + (params.toString() ? `?${params.toString()}` : ""));
            return;
        }
        router.push(`/flux-list/${page}` + (params.toString() ? `?${params.toString()}` : ""));
    };
    const handleNavigateToFetchedContents = (fetchingID)=>{
        router.push(`/flux-list/processing-history/fetched-content?fetchingId=${fetchingID}`);
    };
    const handleNavigateToFetchedContentsFromProcessing = (processingID)=>{
        router.push(`/flux-list/processing-history/fetched-content?processingId=${processingID}`);
    };
    const handleViewProcessingDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardPage.useCallback[handleViewProcessingDetails]": async (processingID)=>{
            try {
                // Fetch the processing data to get the actual flux ID
                const response = await fetch(`/api/processing-history/by-id?processingId=${processingID}`);
                const result = await response.json();
                let actualFluxId = "all";
                let fluxName = `Flux ${processingID}`;
                if (result.data && !result.error) {
                    actualFluxId = String(result.data.fluxID);
                    console.log("🔍 Dashboard: Got actual flux ID for processing", processingID, ":", actualFluxId);
                    // Also try to get the flux name
                    try {
                        const fluxResponse = await fetch(`/api/reports/${actualFluxId}`);
                        const fluxResult = await fluxResponse.json();
                        if (fluxResult.data && !fluxResult.error) {
                            fluxName = fluxResult.data.name || `Flux ${actualFluxId}`;
                        }
                    } catch (fluxError) {
                        console.warn("Could not fetch flux name:", fluxError);
                    }
                } else {
                    console.warn("Could not fetch processing data, using fallback fluxId:", result.error);
                }
                openBlade({
                    "DashboardPage.useCallback[handleViewProcessingDetails]": ()=>__turbopack_context__.r("[project]/components/processing-history/processing-history-details-blade.tsx [app-client] (ecmascript, async loader)")(__turbopack_context__.i)
                }["DashboardPage.useCallback[handleViewProcessingDetails]"], {
                    processingId: processingID,
                    fluxName: fluxName,
                    fluxId: actualFluxId,
                    onClose: closeTopBlade
                }, fluxName);
            } catch (error) {
                console.error("Error fetching processing details:", error);
                // Fallback to original behavior if something goes wrong
                openBlade({
                    "DashboardPage.useCallback[handleViewProcessingDetails]": ()=>__turbopack_context__.r("[project]/components/processing-history/processing-history-details-blade.tsx [app-client] (ecmascript, async loader)")(__turbopack_context__.i)
                }["DashboardPage.useCallback[handleViewProcessingDetails]"], {
                    processingId: processingID,
                    fluxName: `Flux ${processingID}`,
                    fluxId: "",
                    onClose: closeTopBlade
                }, `Flux ${processingID}`);
            }
        }
    }["DashboardPage.useCallback[handleViewProcessingDetails]"], [
        openBlade,
        closeTopBlade
    ]);
    const handleViewFetchingDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardPage.useCallback[handleViewFetchingDetails]": (fetchingID)=>{
            openBlade({
                "DashboardPage.useCallback[handleViewFetchingDetails]": ()=>__turbopack_context__.r("[project]/components/fetching-history/fetching-history-details-blade.tsx [app-client] (ecmascript, async loader)")(__turbopack_context__.i)
            }["DashboardPage.useCallback[handleViewFetchingDetails]"], {
                fetchingId: fetchingID,
                fluxName: `Fetching ${fetchingID}`,
                fluxId: "",
                onClose: closeTopBlade
            }, `Fetching ${fetchingID}`);
        }
    }["DashboardPage.useCallback[handleViewFetchingDetails]"], [
        openBlade,
        closeTopBlade
    ]);
    const handleViewNormalizationDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardPage.useCallback[handleViewNormalizationDetails]": (id)=>{
            openBlade({
                "DashboardPage.useCallback[handleViewNormalizationDetails]": ()=>__turbopack_context__.r("[project]/components/normalization-history/NormalizationDetailsBlade.tsx [app-client] (ecmascript, async loader)")(__turbopack_context__.i)
            }["DashboardPage.useCallback[handleViewNormalizationDetails]"], {
                normalizationId: id,
                fluxName: `Flux ${id}`,
                fluxId: "",
                onClose: closeTopBlade
            }, `Flux ${id}`);
        }
    }["DashboardPage.useCallback[handleViewNormalizationDetails]"], [
        openBlade,
        closeTopBlade
    ]);
    const handleViewRefinementDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardPage.useCallback[handleViewRefinementDetails]": (id)=>{
            openBlade({
                "DashboardPage.useCallback[handleViewRefinementDetails]": ()=>__turbopack_context__.r("[project]/components/refinement-history/RefinementDetailsBlade.tsx [app-client] (ecmascript, async loader)")(__turbopack_context__.i)
            }["DashboardPage.useCallback[handleViewRefinementDetails]"], {
                refinementId: id,
                fluxName: `Flux ${id}`,
                fluxId: "",
                onClose: closeTopBlade
            }, `Flux ${id}`);
        }
    }["DashboardPage.useCallback[handleViewRefinementDetails]"], [
        openBlade,
        closeTopBlade
    ]);
    const handleViewCalculationDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardPage.useCallback[handleViewCalculationDetails]": (id)=>{
            openBlade({
                "DashboardPage.useCallback[handleViewCalculationDetails]": ()=>__turbopack_context__.r("[project]/components/calculation-history/CalculationDetailsBlade.tsx [app-client] (ecmascript, async loader)")(__turbopack_context__.i)
            }["DashboardPage.useCallback[handleViewCalculationDetails]"], {
                calculationId: id,
                fluxName: `Flux ${id}`,
                fluxId: "",
                onClose: closeTopBlade
            }, `Flux ${id}`);
        }
    }["DashboardPage.useCallback[handleViewCalculationDetails]"], [
        openBlade,
        closeTopBlade
    ]);
    const handleViewWorkflowDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "DashboardPage.useCallback[handleViewWorkflowDetails]": async (workflowId)=>{
            const res = await fetch(`/api/workflow-execution-log/item?id=${workflowId}`, {
                cache: "no-store"
            });
            const { data } = await res.json();
            if (!data) return;
            openBlade({
                "DashboardPage.useCallback[handleViewWorkflowDetails]": ()=>__turbopack_context__.r("[project]/components/workflow-execution-log/workflow-item-details-blade.tsx [app-client] (ecmascript, async loader)")(__turbopack_context__.i)
            }["DashboardPage.useCallback[handleViewWorkflowDetails]"], {
                item: data,
                onClose: closeTopBlade,
                onViewFetching: handleViewFetchingDetails,
                onViewProcessing: handleViewProcessingDetails,
                onViewNormalization: handleViewNormalizationDetails,
                onViewRefinement: handleViewRefinementDetails,
                onViewCalculation: handleViewCalculationDetails,
                onContentClick: {
                    "DashboardPage.useCallback[handleViewWorkflowDetails]": (id)=>{
                        router.push(`/flux-list/processing-history/fetched-content?fetchingId=${id}`);
                    }
                }["DashboardPage.useCallback[handleViewWorkflowDetails]"]
            }, data.flux_name || `Flux ${data.flux_id}`);
        }
    }["DashboardPage.useCallback[handleViewWorkflowDetails]"], [
        openBlade,
        closeTopBlade,
        handleViewFetchingDetails,
        handleViewProcessingDetails,
        handleViewNormalizationDetails,
        handleViewRefinementDetails,
        handleViewCalculationDetails,
        router
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-4 md:p-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$view$2d$flux$2d$blade$2f$SummaryOverview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            fluxId: "all",
            onNavigate: handleNavigate,
            onNavigateToFetchedContents: handleNavigateToFetchedContents,
            onNavigateToFetchedContentsFromProcessing: handleNavigateToFetchedContentsFromProcessing,
            onViewFetchingDetails: handleViewFetchingDetails,
            onViewProcessingDetails: handleViewProcessingDetails,
            onViewWorkflowDetails: handleViewWorkflowDetails,
            onViewNormalizationDetails: handleViewNormalizationDetails,
            onViewRefinementDetails: handleViewRefinementDetails,
            onViewCalculationDetails: handleViewCalculationDetails
        }, void 0, false, {
            fileName: "[project]/app/(app)/dashboard/page.tsx",
            lineNumber: 195,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(app)/dashboard/page.tsx",
        lineNumber: 194,
        columnNumber: 5
    }, this);
}
_s(DashboardPage, "7ADg6Rzklgs5l5SrR04M63DL3Rs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$2$2e$4_$40$babel$2b$core$40$7$2e$28$2e$0_$40$playwright$2b$test$40$1$2e$54$2e$1_react$2d$dom$40$19$2e$0$2e$0_react$40$19$2e$0$2e$0_$5f$react$40$19$2e$0$2e$0$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$blade$2d$stack$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBladeStack"]
    ];
});
_c = DashboardPage;
var _c;
__turbopack_context__.k.register(_c, "DashboardPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=app_%28app%29_dashboard_page_tsx_2f7c1466._.js.map