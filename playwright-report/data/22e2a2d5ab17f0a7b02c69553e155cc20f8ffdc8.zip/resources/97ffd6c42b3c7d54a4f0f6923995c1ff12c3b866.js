(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(app)_layout_tsx_e4f28687._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(app)_layout_tsx_e4f28687._.js",
  "chunks": [
    "static/chunks/[root of the server]__a82c5ea5._.css",
    "static/chunks/[root of the server]__2ae2ec7f._.js",
    "static/chunks/components_ui_1e91b493._.js",
    "static/chunks/components_layout_61ac4db8._.js",
    "static/chunks/components_activity_4fad9149._.js",
    "static/chunks/components_blade_eb86e0ae._.js",
    "static/chunks/components_forms_5c11e61f._.js",
    "static/chunks/components_edit-flux-blade_a4d19647._.js",
    "static/chunks/components_view-flux-blade_800bac56._.js",
    "static/chunks/components_processing-history_1d5c1e21._.js",
    "static/chunks/components_fetching-history_561b1441._.js",
    "static/chunks/components_fetched-contents_5a34faad._.js",
    "static/chunks/components_workflow-execution-log_1809f535._.js",
    "static/chunks/components_ea93be7e._.js",
    "static/chunks/_47814aa7._.js",
    "static/chunks/[next]_internal_font_google_9aa55553._.js",
    "static/chunks/72263_next_2f520c56._.js",
    "static/chunks/9398e_lucide-react_dist_esm_icons_6c114d0e._.js",
    "static/chunks/1c600_date-fns_8eb6a158._.js",
    "static/chunks/5fa88_@radix-ui_react-select_dist_index_mjs_a54fe5e5._.js",
    "static/chunks/4cb14_@radix-ui_react-icons_dist_react-icons_esm_59cf0437.js",
    "static/chunks/b6d89_@hello-pangea_dnd_dist_dnd_esm_0f3f22f6.js",
    "static/chunks/b1beb_recharts_es6_util_0199f357._.js",
    "static/chunks/b1beb_recharts_es6_state_f1385ca0._.js",
    "static/chunks/b1beb_recharts_es6_component_d4150b14._.js",
    "static/chunks/b1beb_recharts_es6_cartesian_282d5894._.js",
    "static/chunks/b1beb_recharts_es6_d2890922._.js",
    "static/chunks/65f10_@reactflow_core_dist_esm_index_mjs_5a5d4cf7._.js",
    "static/chunks/node_modules__pnpm_e5b662c9._.js"
  ],
  "source": "dynamic"
});
