(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/components_layout_global-advanced-filter_tsx_5a7e9181._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/components_layout_global-advanced-filter_tsx_5a7e9181._.js",
  "chunks": [
    "static/chunks/components_06aea90c._.js",
    "static/chunks/node_modules__pnpm_678da609._.js"
  ],
  "source": "dynamic"
});
