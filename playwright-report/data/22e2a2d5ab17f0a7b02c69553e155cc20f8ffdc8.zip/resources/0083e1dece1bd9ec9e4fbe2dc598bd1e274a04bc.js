(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(app)_dashboard_page_tsx_e7f35b99._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(app)_dashboard_page_tsx_e7f35b99._.js",
  "chunks": [
    "static/chunks/components_d80faaca._.js",
    "static/chunks/app_(app)_dashboard_page_tsx_2f7c1466._.js"
  ],
  "source": "dynamic"
});
