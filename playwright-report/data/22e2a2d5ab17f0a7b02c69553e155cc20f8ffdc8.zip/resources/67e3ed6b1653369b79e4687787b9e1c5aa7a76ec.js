(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/components_d80faaca._.js", {

"[project]/components/processing-history/processing-history-details-blade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/processing-history/processing-history-details-blade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/fetching-history/fetching-history-details-blade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/fetching-history/fetching-history-details-blade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/normalization-history/NormalizationDetailsBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/normalization-history/NormalizationDetailsBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/refinement-history/RefinementDetailsBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/refinement-history/RefinementDetailsBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/calculation-history/CalculationDetailsBlade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/components/calculation-history/CalculationDetailsBlade.tsx [app-client] (ecmascript)");
    });
});
}}),
"[project]/components/workflow-execution-log/workflow-item-details-blade.tsx [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/components_986c976e._.js",
  "static/chunks/components_workflow-execution-log_b8c5995e._.js",
  "static/chunks/components_workflow-execution-log_workflow-item-details-blade_tsx_97670b59._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/workflow-execution-log/workflow-item-details-blade.tsx [app-client] (ecmascript)");
    });
});
}}),
}]);