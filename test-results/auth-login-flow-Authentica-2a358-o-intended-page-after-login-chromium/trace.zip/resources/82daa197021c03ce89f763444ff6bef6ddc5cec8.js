(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_not-found_tsx_e4f28687._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_not-found_tsx_e4f28687._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7599cdb4._.js",
    "static/chunks/72263_next_dist_73cf77ab._.js"
  ],
  "source": "dynamic"
});
